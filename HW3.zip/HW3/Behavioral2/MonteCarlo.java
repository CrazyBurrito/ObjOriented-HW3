

class MonteCarlo implements Strategy {
    public int execute() {
        System.out.println("I'm making a move using the MonteCarlo AI.");
        return 1; 
    }
}