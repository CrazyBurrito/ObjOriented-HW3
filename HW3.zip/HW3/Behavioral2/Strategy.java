

interface Strategy {
    int execute(); 
}
 