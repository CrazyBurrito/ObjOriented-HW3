

class Minimax implements Strategy {
    public int execute() {
        System.out.println("I'm making a move using the Minimax AI.");
        return 1; 
    }
}