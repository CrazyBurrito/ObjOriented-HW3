

class TreeSearch implements Strategy {
    public int execute() {
        System.out.println("I'm making a move using the TreeSearch AI.");
        return 1; 
    }
}