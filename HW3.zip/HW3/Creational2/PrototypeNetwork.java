
public interface PrototypeNetwork {
	public abstract Object clone ( );
}

