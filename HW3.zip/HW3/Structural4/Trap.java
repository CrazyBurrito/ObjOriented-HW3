
public interface Trap {

	public void trigger();
}